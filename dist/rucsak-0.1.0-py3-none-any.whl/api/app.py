import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from routes import data_contract_routes, data_product_routes, business_glossary_routes, catalog_commander_routes, entitlements_routes, settings_routes, notifications_routes, search_routes
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

# Ensure environment variable is set correctly
assert os.getenv(
    'DATABRICKS_WAREHOUSE_ID'), "DATABRICKS_WAREHOUSE_ID must be set in app.yaml."

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/", StaticFiles(directory="static", html=True), name="static")

# Register routes from each module
data_product_routes.register_routes(app)
data_contract_routes.register_routes(app)
business_glossary_routes.register_routes(app)
entitlements_routes.register_routes(app)
catalog_commander_routes.register_routes(app)
settings_routes.register_routes(app)
notifications_routes.register_routes(app)
search_routes.register_routes(app)

@app.get("/api/time")
async def get_current_time():
    return {'time': time.time()}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, debug=True)
