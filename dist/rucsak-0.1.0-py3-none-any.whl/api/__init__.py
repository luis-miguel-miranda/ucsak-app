"""
Databricks App API package.

This package provides a FastAPI-based API for managing Unity Catalog and related services.
"""

__version__ = "1.0.0" 