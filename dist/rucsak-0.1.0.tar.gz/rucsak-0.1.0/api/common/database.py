from typing import Optional, Dict, List, Any, TypeVar, Type
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime

from .logging import get_logger

logger = get_logger(__name__)

T = TypeVar('T')

@dataclass
class InMemorySession:
    """In-memory session for managing transactions."""
    changes: List[Dict[str, Any]]
    
    def __init__(self):
        self.changes = []
    
    def commit(self):
        """Commit changes to the global store."""
        pass
    
    def rollback(self):
        """Discard changes."""
        self.changes = []

class InMemoryStore:
    """In-memory storage system."""
    
    def __init__(self):
        """Initialize the in-memory store."""
        self._data: Dict[str, List[Dict[str, Any]]] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}
    
    def create_table(self, table_name: str, metadata: Dict[str, Any] = None) -> None:
        """Create a new table in the store.
        
        Args:
            table_name: Name of the table
            metadata: Optional metadata for the table
        """
        if table_name not in self._data:
            self._data[table_name] = []
            if metadata:
                self._metadata[table_name] = metadata
    
    def insert(self, table_name: str, data: Dict[str, Any]) -> None:
        """Insert a record into a table.
        
        Args:
            table_name: Name of the table
            data: Record to insert
        """
        if table_name not in self._data:
            self.create_table(table_name)
        
        # Add timestamp and id if not present
        if 'id' not in data:
            data['id'] = str(len(self._data[table_name]) + 1)
        if 'created_at' not in data:
            data['created_at'] = datetime.utcnow().isoformat()
        if 'updated_at' not in data:
            data['updated_at'] = data['created_at']
        
        self._data[table_name].append(data)
    
    def get(self, table_name: str, id: str) -> Optional[Dict[str, Any]]:
        """Get a record by ID.
        
        Args:
            table_name: Name of the table
            id: Record ID
            
        Returns:
            Record if found, None otherwise
        """
        if table_name not in self._data:
            return None
        return next((item for item in self._data[table_name] if item['id'] == id), None)
    
    def get_all(self, table_name: str) -> List[Dict[str, Any]]:
        """Get all records from a table.
        
        Args:
            table_name: Name of the table
            
        Returns:
            List of records
        """
        return self._data.get(table_name, [])
    
    def update(self, table_name: str, id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a record.
        
        Args:
            table_name: Name of the table
            id: Record ID
            data: Updated data
            
        Returns:
            Updated record if found, None otherwise
        """
        if table_name not in self._data:
            return None
            
        for item in self._data[table_name]:
            if item['id'] == id:
                item.update(data)
                item['updated_at'] = datetime.utcnow().isoformat()
                return item
        return None
    
    def delete(self, table_name: str, id: str) -> bool:
        """Delete a record.
        
        Args:
            table_name: Name of the table
            id: Record ID
            
        Returns:
            True if deleted, False otherwise
        """
        if table_name not in self._data:
            return False
            
        initial_length = len(self._data[table_name])
        self._data[table_name] = [item for item in self._data[table_name] if item['id'] != id]
        return len(self._data[table_name]) < initial_length
    
    def clear(self, table_name: str) -> None:
        """Clear all records from a table.
        
        Args:
            table_name: Name of the table
        """
        if table_name in self._data:
            self._data[table_name] = []

class DatabaseManager:
    """Manages in-memory database operations."""
    
    def __init__(self) -> None:
        """Initialize the database manager."""
        self.store = InMemoryStore()
    
    @contextmanager
    def get_session(self) -> InMemorySession:
        """Get a database session.
        
        Yields:
            In-memory session
            
        Raises:
            Exception: If session operations fail
        """
        session = InMemorySession()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {str(e)}")
            raise
    
    def dispose(self) -> None:
        """Clear all data from the store."""
        self.store = InMemoryStore()

# Global database manager instance
db_manager: Optional[DatabaseManager] = None

def init_db() -> None:
    """Initialize the global database manager."""
    global db_manager
    db_manager = DatabaseManager()

def get_db() -> InMemorySession:
    """Get a database session from the global manager.
    
    Returns:
        In-memory session
        
    Raises:
        RuntimeError: If database manager is not initialized
    """
    if not db_manager:
        raise RuntimeError("Database manager not initialized")
    return db_manager.get_session() 